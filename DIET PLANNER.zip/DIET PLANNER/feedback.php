<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $message = $_POST["message"];

  // Send email to website owner
  $to = "iamabhishek404@gmail.com";
  $subject = "New feedback from website";
  $body = "Name: $name\nEmail: $email\n\n$message";
  $headers = "From: $email";

  if (mail($to, $subject, $body, $headers)) {
    echo "<p>Your feedback has been sent. Thank you!</p>";
  } else {
    echo "<p>There was an error sending your feedback. Please try again later.</p>";
  }
}
?>
